package com.example.HMS_Project.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.HMS_Project.Entity.Admin;
import com.example.HMS_Project.Repository.AdminRepository;

@Service
@Transactional
public class AdminService {
	
	@Autowired
	private AdminRepository adminRepo;
	
	public Admin login(String username, String password) {
        Admin admin = adminRepo.findByUsernameAndPassword(username, password);
        return admin;
    }

}
