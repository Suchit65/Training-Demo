package com.example.HMS_Project.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.HMS_Project.Entity.Admin;
import com.example.HMS_Project.Entity.Employee;
import com.example.HMS_Project.Services.AdminService;
import com.example.HMS_Project.Services.EmployeeService;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
    private EmployeeService service;
	
	@RequestMapping("/adminLogin")
	public String index1(Model model) {
		model.addAttribute("admin", new Admin());
		return "adminLogin";
	}
	
	@GetMapping("/indexAdmin")
	public String viewHomePage1(Model model, HttpSession session) {
	    List<Employee> listEmployee = service.listAll();
	    model.addAttribute("listEmployee", listEmployee);  
	    String username = "ADMIN";
	    model.addAttribute("username", username);
	    return "indexAdmin";
	}
	
	@RequestMapping(value="/postlogin", method = RequestMethod.POST)
	public String adminLogin( @ModelAttribute("admin") Admin admin, HttpServletRequest request) {
		
		String username = admin.getUsername();
		String password = admin.getPassword();
		
		System.out.println(" post login");
			if(adminService.login(username, password) != null) {
				request.getSession().getAttribute(username);
				request.getSession().getAttribute(password);
				request.getSession().setAttribute(username, password);				
				System.out.println("====login");
				return "redirect:/indexAdmin";
			}
			else {
				return "redirect:/adminLogin";
			}		
	}
	
	@RequestMapping(value="/logoutUsers", method = RequestMethod.POST )
	public String adminLogout(HttpServletRequest  request) {
		request.getSession().invalidate();
		System.out.println("====logout");
		return "redirect:/";
	}

}
