package com.example.HMS_Project.Services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HMS_Project.Entity.Room;
import com.example.HMS_Project.Repository.RoomsRepo;

@Service
@Transactional
public class RoomService {
	
	@Autowired
	private RoomsRepo roomsRepo;

	public List<Room> getAllRooms(){
		return roomsRepo.findAll();
	}
	public void saveRoom(Room room) {
		roomsRepo.save(room);
	}
	public Room getRoomById(int id) {
		return roomsRepo.findById(id).get();
	}
	
}
