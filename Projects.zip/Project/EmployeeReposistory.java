package com.example.HMS_Project.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.HMS_Project.Entity.Employee;

public interface EmployeeReposistory extends JpaRepository<Employee, Integer>
{
//	Employee findByEmailAndPassword(String email, String password);
	
	Employee findByNameAndPassword(String name, String password);
}
