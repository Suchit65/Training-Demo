package com.example.HMS_Project.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.Room;
import com.example.HMS_Project.Entity.User;
import com.example.HMS_Project.Repository.UserRepository;
import com.example.HMS_Project.Services.BookingService;
import com.example.HMS_Project.Services.RoomService;
import com.example.HMS_Project.Services.UserService;

@Controller
public class UserController {

	@Autowired
	private UserRepository urepo;

	@Autowired
	private RoomService roomService;

	@Autowired
	private UserService userService;

	@Autowired
	private BookingService bookingService;

	@RequestMapping("/")
	public String index() {
		return "index";
	}

	@RequestMapping("/about-us")
	public String aboutus() {
		return "/about-us";
	}

	@RequestMapping("/contact-us")
	public String contactus() {
		return "/Contact-us";
	}

	@RequestMapping("/userlogin")
	public String index1(Model model, HttpServletRequest request) {
		Map<String, ?> inputFlashMap = RequestContextUtils.getInputFlashMap(request);
		model.addAttribute("user", new User());
		System.out.println(inputFlashMap);
		return "userLogin";
	}

	@RequestMapping("/userIndex")
	public String userIndex(@ModelAttribute("user") User user, Model model, HttpSession session) {
		model.addAttribute("user", user);
		return "userIndex";
	}

	@RequestMapping(value = "/userIndex", method = RequestMethod.POST)
	public String userIndexPost(@ModelAttribute("user") User user, Model model, HttpSession session) {

		String name = user.getName();
		String password = user.getPassword();

		User loggedInUser = userService.userLogin(name, password);
		if (loggedInUser != null) {
			session.getAttribute(name);
			session.setAttribute("name", loggedInUser.getName());
			session.setAttribute("user_id", loggedInUser.getId());
			System.out.println("User Id : " + session.getAttribute("user_id"));
			return "userIndex";
		} else {
			model.addAttribute("result", "error");
			model.addAttribute("message", "Invalid username and password");
			return "userLogin";
		}
	}

	@RequestMapping(value = "/logoutUser", method = RequestMethod.POST)
	public String userLogout(HttpSession session) {
		session.removeAttribute("name");
		session.removeAttribute("user_id");
		session.invalidate();
		System.out.println("====logout");
		return "redirect:/";
	}

	@GetMapping("/signup")
	public String index2(Model model) {
		model.addAttribute("user", new User());
		return "Registration";
	}

	@PostMapping("/process_register")
	public String index3(User user, RedirectAttributes ra) {
		//ModelAndView mav = new ModelAndView("redirect:/userlogin");
		String password = user.getPassword();
		user.setPassword(password);
		if (urepo.save(user) != null) {
			ra.addFlashAttribute("result", "success");
			ra.addFlashAttribute("message", "You've successfully registered");
		} else {
			ra.addFlashAttribute("result", "error");
			ra.addFlashAttribute("message", "Sorry, could not process your request at the moment");
		}

		return "redirect:/userlogin";
	}

	@RequestMapping("/mybookingdetails")
	public String viewHomePage2(Model model, HttpSession session) {
		List<Booking> bookings = userService.findBookings((Integer) session.getAttribute("user_id"));
		model.addAttribute("bookings", bookings);
		return "myBookingDetails";
	}

	@GetMapping("/cancelBooking/{bookingId}")
	public String cancelBooking(@PathVariable(name = "bookingId") Integer bookingId) {
		bookingService.cancelBooking(bookingId);
		return "redirect:/mybookingdetails";
	}

}
