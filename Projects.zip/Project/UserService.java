package com.example.HMS_Project.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.User;
import com.example.HMS_Project.Repository.GuestBookingRepository;
import com.example.HMS_Project.Repository.UserRepository;
@Service
public class UserService 
{
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private GuestBookingRepository guestepo;
	
//	public User userLogin(String email) {
//		User user = userRepository.findByEmail(email);
//		System.out.println("email"+user);
//		
//		return user;
//	}
	
	public User userLogin(String name, String password) {
		User user = userRepository.findByNameAndPassword(name, password);
		return user;
	}
	
    public List<Booking> guestdetailAll() {
        return guestepo.findAll();
    }
    
    public List<Booking> findBookings(Integer userId) {
    	return guestepo.findByUserId(userId);
    	
    }
     

}
