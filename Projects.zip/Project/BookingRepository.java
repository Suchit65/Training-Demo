package com.example.HMS_Project.Repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.Room;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {

//	//@Query("select * from hms.rooms where id not in (select room_id from hms.booking where check_in_date >= :checkInDate and check_out_date <= :checkOutDate )")
//	@Query(value ="select * from Rooms where id not in (select room_id from Booking where check_in_date >= :checkInDate and check_out_date <= :checkOutDate )",nativeQuery=true)
//	List<Booking> findByCheckInDateAndCheckOutDate(Date checkInDate, Date checkOutDate);

//	@Query("select r from Rooms r where r.id not in (select b.roomId from Booking b where b.checkInDate >= :fromDt and b.checkOutDate <= :toDt)")

//	@Query("select r from Rooms r where r.checkInDate >= :fromDt and b.checkOutDate <= :toDt)")
//	public List<Room> findRoomsBetweenDates1(@Param(value = "fromDt") Date fromDt, @Param(value = "toDt") Date toDt);

//	projection 
//	@Query(value="select * from Room r where r.id not in (select b.room_id from Booking b where b.check_in_date >= :fromDt and b.check_out_date <= :toDt)", nativeQuery=true)
	@Query("select r from Room r where r.id not in (select b.room.id from Booking b where :fromDt between b.checkInDate and b.checkOutDate or :toDt between b.checkInDate and b.checkOutDate and b.status = 'Booked')")
	List<Room> findRoomsBetweenDates(Date fromDt, Date toDt);
	
	@Modifying
	@Query("update Booking b set b.status = 'Cancelled' where b.bookingId = :bookingId")
	void cancelBooking(Integer bookingId);

}
