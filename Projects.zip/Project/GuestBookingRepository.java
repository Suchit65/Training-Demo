package com.example.HMS_Project.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.HMS_Project.Entity.Booking;

public interface GuestBookingRepository extends JpaRepository<Booking, Integer> {
	
	@Query("SELECT b FROM Booking b WHERE user.id = :userId")
	public List<Booking> findByUserId(Integer userId);

}
