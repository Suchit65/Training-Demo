package com.example.HMS_Project.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.HMS_Project.Entity.Employee;
import com.example.HMS_Project.Repository.EmployeeReposistory;

@Service
@Transactional
public class EmployeeService 
{
	@Autowired
    private EmployeeReposistory repo;
	
	public Employee employeelogin(String name, String password) {
		Employee employee = repo.findByNameAndPassword(name, password);
        return employee;
	}
     
    public List<Employee> listAll() {
        return repo.findAll();
    }
     
    public void save(Employee employee) {
        repo.save(employee);
    }
     
    public Employee get(int id) {
        return repo.findById(id).get();
    }
     
    public void delete(int id) {
        repo.deleteById(id);
    }
}
