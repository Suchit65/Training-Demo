package com.example.HMS_Project.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.Employee;
import com.example.HMS_Project.Services.EmployeeService;
import com.example.HMS_Project.Services.UserService;




@Controller
public class EmployeeController
{
	
	@Autowired
    private EmployeeService employeeService;
	
	@Autowired
	private UserService userService;	
	
	
	@RequestMapping("/new")
	public String showNewEmployeePage(Model model) {
	    model.addAttribute("employee", new Employee());
	    return "new";
	}
	  
	@PostMapping("/ssave")
		public String index2(Employee employee) {
		employeeService.save(employee);
			return "redirect:/indexAdmin";
		}
	
	  @GetMapping("/edit/{id}")  
	  public ModelAndView showEditProductPage(@PathVariable(name ="id") int id)
	  { 
		  ModelAndView mav =new ModelAndView("EditEmployee"); 
		  Employee employee =employeeService.get(id); 
		  mav.addObject("employee", employee);
		  return mav; 
	  }	  
	  
	  @GetMapping("/delete/{id}") 
	  public String deleteProduct(@PathVariable(name ="id") int id) 
	  { 
		  employeeService.delete(id); 
		  return "redirect:/indexAdmin"; 		  
	  }
	  
		@RequestMapping("/employeelogin")
		public String index2(Model model) {
			model.addAttribute("employee", new Employee());
			return "employeelogin";
		}
		
		@RequestMapping("/guestdetails")
		public String viewHomePage2(Model model, HttpSession session) {
			List<Booking> listguest = userService.guestdetailAll();
		    model.addAttribute("listguest",listguest );
		    
		    String name = "Employee";
		    model.addAttribute("name", name);
		    return "guestdetails";
		}
		
		@RequestMapping(value="/guestdetails",method=RequestMethod.POST)
		public String employeelogin(@ModelAttribute("employee") Employee employee, HttpServletRequest request) {
			
			String name = employee.getName();
			String password = employee.getPassword();
			
			if(employeeService.employeelogin(name, password)!=null) {
				
				request.getSession().getAttribute(name);
				request.getSession().setAttribute(name, password);
				
				return "redirect:/guestdetails";
			}
			else {
				return "redirect:/employeelogin";
			}
		}
		

}
