package com.example.HMS_Project.Services;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.Employee;
import com.example.HMS_Project.Entity.Room;
import com.example.HMS_Project.Repository.BookingRepository;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;

//	public List<Booking> availableRooms(Date checkInDate, Date checkOutDate ) {
//		List<Booking> book = bookingRepository.findByCheckInDateAndCheckOutDate(checkInDate, checkOutDate);
//		return book;
//	}

	public List<Room> availableRooms(Date fromDt, Date toDt) {
		List<Room> room = bookingRepository.findRoomsBetweenDates(fromDt, toDt);
		return room;
	}

	public void save(Booking book) {
		bookingRepository.save(book);
	}

	public Booking get(Integer bookingId) {
		return bookingRepository.findById(bookingId).get();
	}

	public void delete(Integer bookingId) {
		bookingRepository.deleteById(bookingId);
	}
	
	@Transactional
	public void cancelBooking(Integer bookingId) {
		bookingRepository.cancelBooking(bookingId);
	}

}
