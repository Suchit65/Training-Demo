package com.example.HMS_Project.Controller;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.Employee;
import com.example.HMS_Project.Entity.Room;
import com.example.HMS_Project.Entity.User;
import com.example.HMS_Project.Repository.BookingRepository;
import com.example.HMS_Project.Services.BookingService;
import com.example.HMS_Project.Services.RoomService;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private RoomService roomService;

	@RequestMapping("/checkAvailability")
	public String checkavailability(@ModelAttribute("book") Booking Book, Model model) {
		return "checkAvailability";
	}

	@RequestMapping(value = "/availableRooms", method = RequestMethod.POST)
	public String availableRooms(@ModelAttribute("room") Room room, Model model, Booking book) {
		Date startDate = book.getCheckInDate();
		Date endDate = book.getCheckOutDate();
		model.addAttribute("availableRooms", bookingService.availableRooms(startDate, endDate));
		System.out.println("startDate : " + startDate + " endDate : " + endDate);
		return "availableRoomList";
	}

//	booking form get mapping and post mapping 

	@RequestMapping("/book/{id}")
	public ModelAndView viewRoomDetail(@PathVariable(name = "id") Integer id, Model model, Booking book, HttpSession session) {
		System.out.println(id);
		ModelAndView mav = new ModelAndView("userRoomBookingForm");
		if(session.getAttribute("user_id") == null) {
			//return "redirect:/userlogin";
			mav = new ModelAndView("redirect:/userlogin");
			mav.addObject("result", "error");
			mav.addObject("message", "Please login first");
			return mav;
		}
		
		Room room = roomService.getRoomById(id);
		book.setRoom(room);
		// mav.addObject("room", room);
		mav.addObject("book", book);
		return mav;
	}

	// user room booking form submission
	@RequestMapping(value = "/saveRoomBookingForm", method = RequestMethod.POST)
	public String submitForm(Booking book, HttpSession session) {
		System.out.println(book);
		User user = new User();
		user.setId((Integer)session.getAttribute("user_id"));
		book.setUser(user);
		bookingService.save(book);
		return "redirect:/userIndex?success";
	}

	// edit booking details by employee
	@RequestMapping(value = "/saveupdate", method = RequestMethod.POST)
	public String saveUpdate(Booking book) {
		System.out.println(book);
		bookingService.save(book);
		return "redirect:/guestdetails?success";
	}

//edit booking and delete booking mapping
	@RequestMapping("/editBooking/{bookingId}")
	public ModelAndView editBooking(@PathVariable(name = "bookingId") Integer bookingId) {
		ModelAndView mav = new ModelAndView("editUserBooking");
		Booking book = bookingService.get(bookingId);
		mav.addObject("book", book);
		return mav;
	}

	@GetMapping("/deleteBooking/{bookingId}")
	public String deleteBooking(@PathVariable(name = "bookingId") Integer bookingId) {
		bookingService.delete(bookingId);
		return "redirect:/guestdetails";
	}

}
