package com.example.HMS_Project.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.HMS_Project.Entity.Booking;
import com.example.HMS_Project.Entity.User;


public interface UserRepository extends JpaRepository<User, Long>
{
//	@Query("Select u from User u where u.email=?1")
//	public User findByEmail(String email);
	
	
	public User findByNameAndPassword(String name, String password);
	


}
