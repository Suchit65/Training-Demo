package com.example.HMS_Project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.HMS_Project.Entity.Room;
import com.example.HMS_Project.Services.RoomService;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class RoomController {

	@Autowired
	private RoomService roomService;
	
	@RequestMapping("/viewrooms")
	public String viewRooms(Model model) {
		model.addAttribute("viewRooms",roomService.getAllRooms());
		return "rooms";
	}
	@RequestMapping("/roomslist")
	public String roomsList(Model model) {
		model.addAttribute("roomsList",roomService.getAllRooms());
		return "roomslist";
	}
	
//	@RequestMapping("/addnewroom")
//	public String addNewRoom(Model model) {
//		Rooms room = new Rooms();
//		model.addAttribute("room",room);
//		return "addnewroom";
//	}
	
	@PostMapping(value = "/saveroom")
	public String saveRoom(Room room) {
		roomService.saveRoom(room);
		return "redirect:/viewrooms";
	}
	
//	@RequestMapping("/updateroom/{id}")
//	public String updateRoom(@PathVariable(value = "id") long id, Model model) {
//		Rooms room = roomService.getRoomById(id);
//		
//		model.addAttribute("room", room);
//		
//		return "webpages/updateroom";
//	}
	
	@RequestMapping("/updateroom/{id}")
	public ModelAndView updateRoom(@PathVariable(name="id")int id) {
	ModelAndView mav = new ModelAndView("updateroom");
	Room room = roomService.getRoomById(id);
	mav.addObject("room",room);
	return mav;
	}
	
	@RequestMapping("/viewroomdetails/{id}")
	public ModelAndView viewRoomDetail(@PathVariable(name="id")int id) {
		ModelAndView mav = new ModelAndView("roomdetails");
		Room room = roomService.getRoomById(id);
		mav.addObject("room", room);
		return mav;
	}
	
//	@RequestMapping("/booking/{rooms_booked}/{id}")
//	public String update_room(@PathVariable(name="roomsBooked")int rooms_booked,@PathVariable(name="id") int id,Model model) {
//		roomService.update_room(rooms_booked, id);
//		model.addAttribute("roomsList",roomService.getAllRooms());
//	 return "roomslist";	
//	}
}
